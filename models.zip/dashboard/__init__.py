"""
Smart Energy RL Dashboard package.
""" 