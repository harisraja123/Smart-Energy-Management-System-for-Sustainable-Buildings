"""
Dashboard pages package.
""" 